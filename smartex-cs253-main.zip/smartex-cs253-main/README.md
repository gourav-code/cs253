# CS253 Groip 16 Project
# S.M.A.R.T.E.X

The 'ui' file has all the front end UI of the software and is made using HTML, CSS, BS5, and Javascript
The 'be' file has the back end of the software.

Deploy the index.html page inside the ui file of the repo to start the system or simply visit https://rikeshsharma.github.io/smartex/index.html to deploy it.
You can clone the repo to your own system using the SSH of the repo and then go to index.html and deploy it using live server.

## Login Credentials:

For Guard:
Username: Guard001
Password: iamsuperguard

For Admin:
Username: Admin001
Password: qwerty@1234

For using the scanner follow the following steps:

1. Download Barcode to PC application on you PC as well as your mobile phone (mobile phone will be used as scanner). You can visit https://barcodetopc.com/ to download it and to read the app's docs.
2. Fire up the app as said in the docs and open the scan page.
3. Scan the ID card of the student and done!

Note:- This software has not been deployed for all of IITK community. So, for test purposes we have only added the team Roll. Nos. at the backend. For Eg: 210297


