// console.log("encryption.js");

// console.log('a');

//const string = prompt('Enter a character: ');

// convert into ASCII value
//const result = string.charCodeAt(0);

//// console.log(`The ASCII value is: ${result}`);


// encrypt();